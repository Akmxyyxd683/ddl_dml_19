You can read the documentation at : http://www.tecnick.com/pagefiles/tcpdf/doc/index.html

it has been removed because of the size of the package of HTML2PDF... 
## Website Sistem Informasi Absensi Siswa SMP ##

Nama dan file database : sisabsi.sql
<br><br>Website ini memakai php 5.6 dan mysql
 login 
 - admin username : admin password: admin
 - guru username pake nip: 19610506199 password pake nip : 19610506199
 - siswa username pake nip: 123456 password pake nip : 123456